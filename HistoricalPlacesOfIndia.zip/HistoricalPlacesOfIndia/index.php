<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Furnitures</title>
    <link rel="stylesheet" href="style.css">
    <!-- BOOTSTRAP PAGE LINK - https://getbootstrap.com/docs/5.0/getting-started/introduction/ -->
    <!-- linking bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">  
</head>
<body>
     <!-- linking bootstrap js -->
     <!-- NAVBAR from bootstrap-->
     <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
          <a class="navbar-brand" href="#" style="font-family:Tahoma">FURNITURES</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto"> <!-- mx-auto->navigation aligned at center -->
              <li class="nav-item">
                <a class="nav-link" href="#home" style="font-family:cursive">HOME&nbsp;</a>    <!--  &nbsp; -> space -->
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about" style="font-family:cursive;">ABOUT&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#product" style="font-family:cursive;">PRODUCTS&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact" style="font-family:cursive;">CONTACT&nbsp;</a>
              </li>
            </ul>
            <button class="btn p-2 my-lg-0 my-2" style="font-family:Trebuchet MS;">Sign In</button>    <!-- Using btn class from bootstrap, p-2 -> padding on 4 sides 2  -->
        </div>
      </nav>
<!-- HOME -->
<section id="home">
     <h1 class="text-center">LUXURY FURNITURES</h1>
     <p style="font-family: monospace;">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ROYAL BRAND Furnitures has the most best quality furnitures for all users in various price ranges. <br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Our products will give you a grand feel. All types of furnitures such as tables,fans,beds,<br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; chairs,doors etc. are available.</p>
     <div class="input-group m-4">
      <input type="text" class="form-control" placeholder="Email Address" style="font-family:Lucida Grande;">
        <button class="btn signin" style="font-family:Arial;">Get Started</button>
     </div>
</section>
<!-- ABOUT -->
<section id="about">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="logo.jpg" class="img-fluid" style="height: 550px;">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 99px;text-align: left;font-family: Cambria;">ABOUT US</h1>
        <p style="position: relative;top:120px;font-family: 'Lucida Sans';font-size: larger;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
</section>
<!-- PRODUCT -->
<section id="product">
  <div class="container m-5">
    <h1 class="text-center my-5">OUR PRODUCTS</h1>
  <div class="row" id="row1">
    <div class="col-lg-4 col-md-4 col-12">
      <!-- https://getbootstrap.com/docs/5.0/components/card/ -->
      <div class="card">
        <img src="img1.png" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Modern Sofa</h5>
          <a href="#modern sofa" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img2.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Bedroom set</h5>
          <a href="#bedroom set" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img3.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">recliner sofa</h5>
          <a href="#recliner sofa" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
  </div> 
  <div class="row">
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img4.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">King bed</h5>
          <a href="#king bed" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img5.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Storage bed</h5>
          <a href="#storage bed" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img6.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Dining Tables</h5>
          <a href="#dining tables" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
  </div> 
  <div class="row">
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img7.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Queen bed</h5>
          <a href="#queen bed" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img8.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Dining Chairs</h5>
          <a href="#dining chairs" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-12">
      <div class="card">
        <img src="img9.jpg" class="card-img-top">
        <div class="card-body text-center">
          <h5 class="card-title">Lounger sofa</h5>
          <a href="#lounger sofa" class="btn signin" style="background:rgb(187, 181, 181) !important">More details</a><br>
          <!-- <a href="#" class="btn signin">Add to cart</a> -->
        </div>
      </div>
    </div>
  </div> 
  </div>
  <button class="btn signin" id="vwcart" href="view cart">View cart</button>
  <script>document.getElementById("vwcart").onclick=function(){location.href="";}</script>
</section>
<!-- MORE DETAILS OF modern sofa -->
<section id="modern sofa">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img1.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">MODERN SOFA</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Modern sofa</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>

    <a href="#" class="btn signin" >Add to cart</a>

</section>

<!-- MORE DETAILS OF bedroom set -->
<section id="bedroom set">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img2.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative ;top: 9px;text-align: left;font-family: Cambria;">BEDROOM SET</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Bedroom set</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>

<!-- MORE DETAILS OF recliner sofa -->
<section id="recliner sofa">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img3.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">RECLINER SOFA</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Recliner sofa</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin">Add to cart</a>
</section>

<!-- MORE DETAILS OF king bed -->
<section id="king bed">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img4.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">KING BED</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;King bed</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>

<!-- MORE DETAILS OF storage bed -->
<section id="storage bed">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img5.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">STORAGE BED</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Storage bed</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>

<!-- MORE DETAILS OF dining tables -->
<section id="dining tables">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img6.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">DINING TABLES</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Dining tables</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>

<!-- MORE DETAILS OF queen bed -->
<section id="queen bed">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img7.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">QUEEN BED</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Queen bed</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>

<!-- MORE DETAILS OF dining chairs -->
<section id="dining chairs">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img8.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">DINING CHAIRS</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Dining chairs</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>

<!-- MORE DETAILS OF lounger sofa -->
<section id="lounger sofa">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="img9.jpg" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
        <h1 style="position: relative;top: 9px;text-align: left;font-family: Cambria;">LOUNGER SOFA</h1>
            <table style="font-family:Times New Roman">
              <tr>
                <td>Product Name:</td>
                <td>&nbsp;Lounger sofa</td>
              </tr>
              <tr>
                <td>Product ID:</td>
                <td>&nbsp;1324</td>
              </tr>
              <tr>
                <td>Prize:</td>
                <td>&nbsp;Rs.99999</td>
              </tr>
              <tr>
                <td>Free delivery available</td>
                <!-- <td>&nbsp;&nbsp;1324</td> -->
              </tr> 
          </table>  
          <p style="position: relative;top:30px;font-family:Calibri;"></p>
          ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
           recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
          aperiam molestias ipsa et iure rem. Ad laborum enim maiores?
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, dolore dolor saepe,
          recusandae libero aliquid amet perferendis repudiandae explicabo beatae, 
         aperiam molestias ipsa et iure rem. Ad laborum enim maiore</p>
      </div>
    </div>
  </div>
  <a href="#" class="btn signin" >Add to cart</a>
</section>



<!-- CONTACT -->
<section id="contact">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
          <img src="contact.png" class="img-fluid">
      </div>
      <div class="col-lg-6 col-md-6 col-12">
          <h1>CONTACT US</h1>
          <form class="mb-3">
            <input type="text" class="form-control" placeholder="Enter your name">
            <input type="email" class="form-control" placeholder="Enter your Email">
            <textarea class="form-control" placeholder="Enter your feedback"></textarea>
            <button class="btn signin">CONTACT</button>
          </form>
      </div>
    </div>
  </div>
  
</section>
<footer>Copyrights @RoyalBrand 2022</footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
</body>
</html>
